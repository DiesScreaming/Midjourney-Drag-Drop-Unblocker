(function() {
    'use strict';

    // Core function to unblock native image tags
    function unblockImage(img) {
        if (img && !img.dataset.dragFixed) {
            img.style.pointerEvents = 'auto';
            img.style.userSelect = 'auto';
            img.draggable = true;
            img.removeAttribute('pointer-events');
            img.dataset.dragFixed = "true"; // Prevents infinite loops
        }
    }

    // 1. REAL-TIME MOUSE OVERRIDE (Triggers the millisecond you click an image)
    document.addEventListener('mousedown', (e) => {
        const img = e.target.closest('img') || e.target.querySelector('img');
        
        if (img) {
            unblockImage(img);
            
            // Travel up the DOM tree to strip any parent containers setup to swallow mouse drags
            let parent = img.parentElement;
            while (parent && parent !== document.body) {
                if (window.getComputedStyle(parent).pointerEvents === 'none') {
                    parent.style.pointerEvents = 'auto';
                }
                parent = parent.parentElement;
            }
        }
    }, true); // Setting to 'true' intercepts the click before Midjourney's scripts can block it

    // 2. LIVE LAYOUT OBSERVER (Watches the gallery grid and fixes new images as you scroll)
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1) { // Check if the node is an HTML element
                    if (node.tagName === 'IMG') {
                        unblockImage(node);
                    }
                    node.querySelectorAll('img').forEach(unblockImage);
                }
            });
        });
    });

    // Fire up the observer as soon as the webpage body loads
    const checkExist = setInterval(() => {
        if (document.body) {
            clearInterval(checkExist);
            observer.observe(document.body, { childList: true, subtree: true });
            
            // Sweep up any images that managed to load before the observer started
            document.querySelectorAll('img').forEach(unblockImage);
        }
    }, 50);
})();